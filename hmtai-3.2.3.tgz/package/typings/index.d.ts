type HMtaiResult = string

declare class hmtai {
    sfw: {
        wave(): Promise<HMtaiResult>
        wink(): Promise<HMtaiResult>
        tea(): Promise<HMtaiResult>
        bonk(): Promise<HMtaiResult>
        punch(): Promise<HMtaiResult>
        poke(): Promise<HMtaiResult>
        bully(): Promise<HMtaiResult>
        pat(): Promise<HMtaiResult>
        kiss(): Promise<HMtaiResult>
        kick(): Promise<HMtaiResult>
        blush(): Promise<HMtaiResult>
        feed(): Promise<HMtaiResult>
        smug(): Promise<HMtaiResult>
        hug(): Promise<HMtaiResult>
        cuddle(): Promise<HMtaiResult>
        cry(): Promise<HMtaiResult>
        slap(): Promise<HMtaiResult>
        five(): Promise<HMtaiResult>
        glomp(): Promise<HMtaiResult>
        happy(): Promise<HMtaiResult>
        hold(): Promise<HMtaiResult>
        nom(): Promise<HMtaiResult>
        smile(): Promise<HMtaiResult>
        throw(): Promise<HMtaiResult>
        lick(): Promise<HMtaiResult>
        bite(): Promise<HMtaiResult>
        dance(): Promise<HMtaiResult>
        boop(): Promise<HMtaiResult>
        sleep(): Promise<HMtaiResult>
        like(): Promise<HMtaiResult>
        kill(): Promise<HMtaiResult>
        tickle(): Promise<HMtaiResult>
        nosebleed(): Promise<HMtaiResult>
        threaten(): Promise<HMtaiResult>
        depression(): Promise<HMtaiResult>
        wolf_arts(): Promise<HMtaiResult>
        jahy_arts(): Promise<HMtaiResult>
        neko_arts(): Promise<HMtaiResult>
        coffee_arts(): Promise<HMtaiResult>
        wallpaper(): Promise<HMtaiResult>
        mobileWallpaper(): Promise<HMtaiResult>
    }
    nsfw: {
        anal(): Promise<HMtaiResult>
        ass(): Promise<HMtaiResult>
        bdsm(): Promise<HMtaiResult>
        cum(): Promise<HMtaiResult>
        classic(): Promise<HMtaiResult>
        creampie(): Promise<HMtaiResult>
        manga(): Promise<HMtaiResult>
        femdom(): Promise<HMtaiResult>
        hentai(): Promise<HMtaiResult>
        incest(): Promise<HMtaiResult>
        masturbation(): Promise<HMtaiResult>
        public(): Promise<HMtaiResult>
        ero(): Promise<HMtaiResult>
        orgy(): Promise<HMtaiResult>
        elves(): Promise<HMtaiResult>
        yuri(): Promise<HMtaiResult>
        pantsu(): Promise<HMtaiResult>
        glasses(): Promise<HMtaiResult>
        cuckold(): Promise<HMtaiResult>
        blowjob(): Promise<HMtaiResult>
        boobjob(): Promise<HMtaiResult>
        footjoob(): Promise<HMtaiResult>
        handjoob(): Promise<HMtaiResult>
        boobs(): Promise<HMtaiResult>
        thighs(): Promise<HMtaiResult>
        pussy(): Promise<HMtaiResult>
        ahegao(): Promise<HMtaiResult>
        gangbang(): Promise<HMtaiResult>
        tentacles(): Promise<HMtaiResult>
        uniform(): Promise<HMtaiResult>
        gif(): Promise<HMtaiResult>
        nsfwNeko(): Promise<HMtaiResult>
        nsfwMobileWallpaper(): Promise<HMtaiResult>
        zettaiRyouiki(): Promise<HMtaiResult>
    }
}

export = hmtai